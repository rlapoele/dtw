import { describe, expect, it } from "vitest";
import { admitSnapshot } from "@application/retention/codec";
import {
  projectContext,
  selectedInspection,
  displayRows,
} from "@application/retention/projections";
const snapshot = admitSnapshot({
  project: { id: "", name: "" },
  groups: [{ id: "", projectId: "", localName: "cycle", parentGroupId: "" }],
  tokens: [
    {
      id: "",
      projectId: "",
      localName: "amount",
      parentGroupId: "",
      description: "exact",
      authoring: { regeneration: "protected" },
      definition: {
        type: "number",
        assignments: [
          {
            condition: [],
            value: { kind: "literal", valueType: "number", value: "1.234" },
          },
        ],
      },
    },
  ],
});
describe("coherent display-only projections", () => {
  it("returns complete identity context without hidden canonical assignments", () => {
    const context = projectContext(snapshot);
    expect(context.tokens[0].authored.definition).toEqual({ type: "number" });
    expect(context.groups[0].path.status).toBe("invalid");
    expect(displayRows(snapshot, 0, 100)[0]).toMatchObject({
      id: "",
      type: "number",
      description: "exact",
      valueKind: "literal",
    });
  });
  it("keeps readonly type/value kind/metadata and actual resolution independent of edit eligibility", () => {
    const selected = selectedInspection(snapshot, "");
    expect(selected.token.definition?.type).toBe("number");
    expect(selected.authoredKind).toBe("literal");
    expect(selected.editable).toBe(false);
    expect(selected.token.description).toBe("exact");
    expect(selected.resolution.status).toBe("resolved");
    expect(selected.token).not.toHaveProperty("definition.assignments");
  });
});
